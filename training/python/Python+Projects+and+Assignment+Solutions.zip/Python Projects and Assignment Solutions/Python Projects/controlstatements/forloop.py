for x in range(50,71,3):
    print(x)