x=1
while(x<=20):
    print(x)
    x+=1 #x=x+1