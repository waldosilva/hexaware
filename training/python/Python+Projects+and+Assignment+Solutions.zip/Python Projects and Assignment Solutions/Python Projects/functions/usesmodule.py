#import mymath as ma
from mymath import * 

print(sum(10, 5))
print(diff(10, 5))