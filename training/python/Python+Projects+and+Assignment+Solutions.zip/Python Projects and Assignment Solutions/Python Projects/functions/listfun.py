def fun(lst):
    for i in lst:
        print(i)
    
fun([1,2,3,4])