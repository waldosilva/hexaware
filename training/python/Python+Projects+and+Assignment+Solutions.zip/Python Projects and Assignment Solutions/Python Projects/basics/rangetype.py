r=range(1,15,3)

for i in r:
    print(i)