
"""s=input()
print(s)
s=input("Enter your name:")
print(s)"""
#i=int(input("Enter a integer number"))
#print(type(i))

lst = [float(x) for x in input("Enter three numbers seperated by comma:").split(',')]
print(lst)

