a=10
b=20.4
c="true"
d="I am the best"
print(a,b,c,d)