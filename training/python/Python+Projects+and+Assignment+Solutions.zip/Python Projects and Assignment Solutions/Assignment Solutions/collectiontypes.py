countries = ["India","USA","CANADA"]
countries.append("SriLanka")
print(countries)
print(countries[1])
countries.remove("USA")
print(countries)
countries.insert(1,"MyCountry")
print(countries)