firstName = "XYZ"
lastName = "DEF"
age = 20
ssn = "100-00-00"
height = "6.1"
weight = 150.55
print(firstName +" " + lastName +" " + str(age) +" " + ssn +" " + height +" " + str(weight))