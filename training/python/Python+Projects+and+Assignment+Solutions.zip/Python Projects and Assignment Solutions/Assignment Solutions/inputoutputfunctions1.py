toppings=['Onions', 'Lettuce', 'Tomato', 'olives', 'peppers']
print(toppings)
s=input(" Choose the toppings")
print(s)
i=int(input("How many do you want?"))
print(i)
total=i*5
print(total)